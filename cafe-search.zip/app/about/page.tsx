import Image from "next/image"

export default function About() {
  return (
    <div className="max-w-4xl mx-auto px-4">
      <h1 className="text-4xl font-bold mb-8 text-center">About CafeQuest Siliguri</h1>
      <div className="space-y-12">
        <section className="text-center">
          <p className="text-lg text-gray-700 mb-8">
            Meet the duo behind CafeQuest Siliguri - two friends who turned their passion for exploring local cafes into
            a mission to help others discover the best of Siliguri's vibrant cafe scene!
          </p>
          <div className="relative h-[400px] rounded-lg overflow-hidden">
            <Image
              src="https://images.unsplash.com/photo-1517048676732-d65bc937f952?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
              alt="Friends enjoying coffee in a cafe"
              width={1470}
              height={980}
              layout="responsive"
              className="rounded-lg"
            />
          </div>
        </section>

        <section>
          <h2 className="text-3xl font-semibold mb-6">Our Caffeinated Mission</h2>
          <div className="flex flex-col md:flex-row items-center md:items-start gap-8">
            <div className="md:w-1/2">
              <p className="text-lg text-gray-700">
                At CafeQuest Siliguri, we believe that great cafes are more than just places to grab a quick chai or
                coffee. They're community hubs, creative spaces, and often the birthplace of brilliant ideas (like ours,
                which was born over a cup of masala chai!). Our mission is to connect Siliguri's coffee and tea lovers
                with their ideal cafe experiences, supporting local businesses and fostering a thriving cafe culture in
                our beloved city.
              </p>
            </div>
            <div className="md:w-1/2">
              <Image
                src="https://images.unsplash.com/photo-1453614512568-c4024d13c247?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1632&q=80"
                alt="A cozy cafe corner with people working and socializing"
                width={1632}
                height={1088}
                className="rounded-lg shadow-md"
              />
            </div>
          </div>
        </section>

        <section>
          <h2 className="text-3xl font-semibold mb-6">Join Our Chai-Coffee Party!</h2>
          <div className="flex flex-col md:flex-row-reverse items-center md:items-start gap-8">
            <div className="md:w-1/2">
              <p className="text-lg text-gray-700">
                Love exploring new cafes as much as we do? Join our community of Siliguri's cafe enthusiasts! Share your
                favorite spots, leave reviews, and connect with fellow cafe-goers. Together, we can create the most
                comprehensive and reliable guide to the best cafes in Siliguri. Don't forget to use our hashtag
                #SiliguriCafeHopping on your Instagram posts!
              </p>
            </div>
            <div className="md:w-1/2">
              <Image
                src="https://images.unsplash.com/photo-1442512595331-e89e73853f31?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
                alt="A group of friends enjoying coffee and pastries"
                width={1470}
                height={980}
                className="rounded-lg shadow-md"
              />
            </div>
          </div>
        </section>

        <section className="text-center">
          <h2 className="text-3xl font-semibold mb-6">Meet the Caffeine Crusaders</h2>
          <p className="text-lg text-gray-700 mb-8">
            We're just two friends who turned our coffee shop hopping hobby into a mission to help others discover the
            best of Siliguri's cafe scene!
          </p>
          <div className="flex flex-col items-center space-y-4">
            {[
              { name: "Santu Saha", role: "Co-founder" },
              { name: "Shubham Agarwal", role: "Co-founder" },
            ].map((member, index) => (
              <div key={index} className="text-center">
                <h3 className="text-xl font-semibold">{member.name}</h3>
                <p className="text-gray-600">{member.role}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}

